package ru.shortcut.content.services;

import ru.shortcut.content.entity.material.Material;

import java.util.List;

public interface ContentService {

    List<Material> search(String title, String lastName, String by, String chapter);


}
