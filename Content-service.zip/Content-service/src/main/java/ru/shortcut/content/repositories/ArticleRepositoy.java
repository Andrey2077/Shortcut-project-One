package ru.shortcut.content.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.shortcut.content.entity.material.Article;

public interface ArticleRepositoy extends JpaRepository <Article, Long> {
}
