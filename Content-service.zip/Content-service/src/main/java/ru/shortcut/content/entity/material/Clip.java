package ru.shortcut.content.entity.material;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "clips")
@Data
@Schema(description = "Видео-ролики")
public class Clip extends Material{

    @NotBlank
    @Column(nullable = false)
    private String path;

}
