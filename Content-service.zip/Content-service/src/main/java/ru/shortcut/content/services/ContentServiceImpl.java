package ru.shortcut.content.services;

import ru.shortcut.content.entity.material.Material;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class ContentServiceImpl implements ContentService{

    @Override
    public List<Material> search(String title, String lastName, String by, String chapter) {
        return null;
    }
}
