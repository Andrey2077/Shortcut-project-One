package ru.shortcut.content.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.shortcut.content.entity.material.Clip;

public interface ClipRepositoy extends JpaRepository <Clip, Long>{
}
